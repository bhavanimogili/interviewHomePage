package com.example.bhavaniinterview.data.local
import android.content.Context
import android.util.Log
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.viewbinding.BuildConfig
import com.example.bhavaniinterview.data.models.Card
import java.util.concurrent.Executors

@Database(
    entities = [Card::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun cardDao(): CardDAO

    companion object {
        private const val DATABASE_NAME: String = "db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context) = INSTANCE ?: synchronized(this) {
            INSTANCE ?: buildDatabase(context).also { INSTANCE = it }
        }

        private fun buildDatabase(context: Context) =
            Room.databaseBuilder(context, AppDatabase::class.java, DATABASE_NAME)
                .fallbackToDestructiveMigration()
                .setQueryCallback({ sqlQuery, _ ->
                    if (BuildConfig.DEBUG) {
                        Log.d("query", sqlQuery)
                    }
                }, Executors.newSingleThreadExecutor())
                .build()
    }
}