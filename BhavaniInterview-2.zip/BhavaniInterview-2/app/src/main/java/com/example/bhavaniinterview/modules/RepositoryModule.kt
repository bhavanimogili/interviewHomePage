package com.example.bhavaniinterview.modules

import com.example.bhavaniinterview.data.local.CardDAO
import com.example.bhavaniinterview.data.network.ApiService
import com.example.bhavaniinterview.data.repositories.CardRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton


@InstallIn(SingletonComponent::class)
@Module
object RepositoryModule {
    @Singleton
    @Provides
    fun provideCardRepository(apiService: ApiService, cardDao: CardDAO) =
        CardRepository(apiService, cardDao)
}