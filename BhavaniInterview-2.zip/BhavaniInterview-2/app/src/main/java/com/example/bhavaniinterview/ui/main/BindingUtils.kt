package com.example.bhavaniinterview.ui.main

import android.graphics.Color
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.RectShape
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.bhavaniinterview.data.models.Description
import com.example.bhavaniinterview.data.models.Image
import com.example.bhavaniinterview.data.models.Title



//binding for the RecyclerView

@BindingAdapter("setThumbnail")
fun ImageView.setThumbnail(image: Image?) {
    val url = image?.url
    if(!url.isNullOrBlank())  visibility = View.VISIBLE else View.GONE
    val placeholder = ShapeDrawable(RectShape()).apply {
        intrinsicWidth = image?.size?.width ?: 1
        intrinsicHeight = image?.size?.height ?: 1
        paint.color = Color.LTGRAY
    }
    Glide.with(context).asBitmap().diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
        .fallback(placeholder).error(placeholder).load(url).into(this)
}

@BindingAdapter("setCardTitle")
fun TextView.setCardTitle(title: Title?) {
    text = title?.value
    textSize = title?.attributes?.font?.size?.toFloat() ?: 24f
    val colour =
        if (title?.attributes?.text_color.isNullOrEmpty()) Color.WHITE else Color.parseColor(title?.attributes?.text_color)
    setTextColor(colour)
}

@BindingAdapter("setCardValue")
fun TextView.setCardValue(value: String?) {
    text = value
}

@BindingAdapter("setCardDescription")
fun TextView.setCardDescription(description: Description?) {
    text = description?.value
    textSize = description?.attributes?.font?.size?.toFloat() ?: 24f
    val colour =
        if (description?.attributes?.text_color.isNullOrEmpty()) Color.WHITE else Color.parseColor(
            description?.attributes?.text_color
        )
    setTextColor(colour)
}