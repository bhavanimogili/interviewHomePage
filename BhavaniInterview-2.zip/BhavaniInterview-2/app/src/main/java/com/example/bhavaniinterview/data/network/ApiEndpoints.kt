package com.example.bhavaniinterview.data.network

import com.example.bhavaniinterview.data.models.ApiResponse
import retrofit2.Response
import retrofit2.http.GET

interface ApiEndpoints {
    @GET("home")
    suspend fun home(): Response<ApiResponse>
}