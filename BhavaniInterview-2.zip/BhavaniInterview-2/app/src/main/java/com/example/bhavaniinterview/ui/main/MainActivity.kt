package com.example.bhavaniinterview.ui.main

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.bhavaniinterview.data.models.CardsUI
import com.example.bhavaniinterview.databinding.ActivityMainBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {
    private val binding by lazy { ActivityMainBinding.inflate(layoutInflater) }
    private val mainViewModel: MainViewModel by viewModels()
    private val mainRecyclerViewAdapter by lazy { MainRecyclerViewAdapter() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        setupView()
        getCards()
    }

    private fun setupView() {
        binding.cardsList.adapter = mainRecyclerViewAdapter
    }

    private fun getCards() {
        mainViewModel.cachedCardsUI.observe(this, {
            //observes the LiveData from ViewModel
            when (it) {
                is CardsUI.CardsLoading -> {
                    //show loading spinner
                }
                is CardsUI.CardsSuccess -> {
                    mainRecyclerViewAdapter.submitList(it.items)
                }
                else -> { //CardsUI.CardsFailure
                    //handle error, maybe show empty "no items" screen, toast or popup
                }
            }
        })

        mainViewModel.setLiveDataForCachedCards()
        //observe cached data and then make network response, as network response gets cached in line 28 MainViewModel

        mainViewModel.getCardsFromNetwork()
    }
}