package com.example.bhavaniinterview.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey


data class ApiResponse(
    val page: Page? = null
)

data class Page(
    val cards: List<Card>? = null
)

@Entity(tableName = "cards")
data class Card(
    @PrimaryKey
    val card: CardX,
    val card_type: String? = null
)

data class CardX(
    val attributes: Attributes? = null,
    val description: Description? = null,
    val image: Image? = null,
    val title: Title? = null,
    val value: String? = null
)

data class Attributes(
    val font: Font? = null,
    val text_color: String? = null
)

data class Description(
    val attributes: AttributesX? = null,
    val value: String? = null
)

data class Image(
    val size: Size? = null,
    val url: String? = null
)

data class Size(
    val height: Int? = null,
    val width: Int? = null
)

data class Title(
    val attributes: AttributesXX? = null,
    val value: String? = null
)

data class AttributesX(
    val font: FontX? = null,
    val text_color: String? = null
)

data class AttributesXX(
    val font: FontXX? = null,
    val text_color: String? = null
)

data class Font(
    val size: Int? = null
)

data class FontX(
    val size: Int? = null
)

data class FontXX(
    val size: Int? = null
)

sealed class CardsUI {
    object CardsLoading : CardsUI()
    class CardsSuccess(val items: MutableList<Card>) : CardsUI()
    object CardsFailure : CardsUI()
}

//used https://github.com/wuseal/JsonToKotlinClass to generate model