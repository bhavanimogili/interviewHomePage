package com.example.bhavaniinterview.data.local

import androidx.room.TypeConverter
import com.example.bhavaniinterview.data.models.CardX
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken

class Converters {
    @TypeConverter
    fun fromCardX(value: CardX?): String? = GsonBuilder().create()
        .toJson(value, TypeToken.getParameterized(CardX::class.java, CardX::class.java).type)

    @TypeConverter
    fun toCardX(value: String?): CardX? = GsonBuilder().create().fromJson<CardX>(
        value,
        TypeToken.getParameterized(CardX::class.java, CardX::class.java).type
    )
}