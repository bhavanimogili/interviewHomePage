package com.example.bhavaniinterview.data.repositories

import com.example.bhavaniinterview.data.local.CardDAO
import com.example.bhavaniinterview.data.models.Card
import com.example.bhavaniinterview.data.network.ApiService

class CardRepository(private val apiService: ApiService, val cardDao: CardDAO) {
    //network
    suspend fun home() = apiService.home()

    //local database
    suspend fun cacheCards(cards: List<Card>) = cardDao.cacheCards(cards)
    fun observeCachedCards() = cardDao.observeCachedCards()
}