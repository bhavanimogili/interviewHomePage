package com.example.bhavaniinterview.ui.main

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.bhavaniinterview.data.models.CardsUI
import com.example.bhavaniinterview.data.repositories.CardRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class MainViewModel @Inject constructor(private val cardRepository: CardRepository) : ViewModel() {
    val cachedCardsUI: MutableLiveData<CardsUI> = MutableLiveData()

    fun getCardsFromNetwork() {
        //do the following on the IO thread
        CoroutineScope(Dispatchers.IO).launch {
            //make network response here
            val homeResponse = cardRepository.home()

            if (homeResponse?.isSuccessful == true && !homeResponse.body()?.page?.cards.isNullOrEmpty()) {
                //caches cards to Database here
                cardRepository.cacheCards(homeResponse.body()!!.page!!.cards!!.toMutableList())
            }
        }
    }

    fun setLiveDataForCachedCards() {
        //set initial loading value to LiveData, so the observer in Activity can show loading spinner
        cachedCardsUI.value = CardsUI.CardsLoading

        //do the following on the IO thread
        CoroutineScope(Dispatchers.IO).launch {
            //observe cached cards from Database here and set it to the MutableLiveData
            cardRepository.observeCachedCards().collectLatest {

                //have to set value of LiveData on Main thread so switch to viewModelScope
                viewModelScope.launch {
                    if (it.isNotEmpty()) {
                        //set success value to LiveData, so the observer in Activity can show the data
                        cachedCardsUI.value = CardsUI.CardsSuccess(it.toMutableList())
                    } else {
                        //set error value to LiveData, so the observer in Activity can show an error message
                        cachedCardsUI.value = CardsUI.CardsFailure
                    }
                }
            }
        }
    }
}