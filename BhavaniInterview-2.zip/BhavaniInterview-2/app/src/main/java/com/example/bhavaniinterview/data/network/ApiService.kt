package com.example.bhavaniinterview.data.network

import com.example.bhavaniinterview.App

class ApiService(private val apiEndpoints: ApiEndpoints) {
    suspend fun home() = if (App.isNetworkAvailable()) apiEndpoints.home() else null
}



