package com.example.bhavaniinterview.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.bhavaniinterview.data.models.Card
import kotlinx.coroutines.flow.Flow

@Dao
interface CardDAO {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun cacheCards(cards: List<Card>): LongArray?

    @Query("SELECT * FROM cards")
    fun observeCachedCards(): Flow<List<Card>>
}
