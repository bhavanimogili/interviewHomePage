package com.example.bhavaniinterview


import com.example.bhavaniinterview.data.local.CardDAO
import com.example.bhavaniinterview.data.models.*
import com.example.bhavaniinterview.data.network.ApiEndpoints
import com.example.bhavaniinterview.data.network.ApiService
import com.example.bhavaniinterview.data.repositories.CardRepository
import com.example.bhavaniinterview.ui.main.MainViewModel
import junit.framework.Assert.assertEquals
import kotlinx.coroutines.runBlocking
import org.junit.Before
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito.doReturn
import org.mockito.Mockito.mock
import retrofit2.Response

class ApiInterfaceUnitTest {

    @Mock
    lateinit var apiEndpoints: ApiEndpoints

    @Mock
    lateinit var cardDAO: CardDAO

    lateinit var apiService: ApiService

    lateinit var cardRepository: CardRepository

    lateinit var mainViewModel: MainViewModel


    @Before
    fun before() {
        apiEndpoints = mock(ApiEndpoints::class.java)
        cardDAO = mock(CardDAO::class.java)
        apiService = ApiService(apiEndpoints)
        cardRepository = CardRepository(apiService, cardDAO)
        mainViewModel = MainViewModel(cardRepository)
    }


    @Test
    fun server_returns_cards() {
        val apiResponse = ApiResponse(Page(listOf(Card(CardX()))))
        runBlocking {
            doReturn(Response.success(apiResponse)).`when`(apiEndpoints).home()
        }
        assertEquals(apiResponse.page?.cards?.size?:0, 1)
    }
}